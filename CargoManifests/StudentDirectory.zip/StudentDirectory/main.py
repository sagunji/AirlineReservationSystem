
from dataview.base import DataView, TestData
from dataview.operations import PROCESSORS as GLOBAL_PROCESSORS

from dataview_plugins.StudentDirectory.utils import get_resource
from dataview_plugins.StudentDirectory.reports import StudentAgeReport
import os
from dataview.utils import get_dv_code

REPORTS = [StudentAgeReport]

TEST_DATAS = [
    TestData("Student", "Student.jsonl"),
    TestData("StudentAssessment", "StudentAssessment.jsonl"),
]

PROCESSORS = {}

GLOBAL_PROCESSORS.update(PROCESSORS)


def main():
    pwd = os.path.dirname(os.path.realpath(__file__))
    dv_code = get_dv_code(pwd)
    dv = DataView("Student Directory", dv_code)
    for report_class in REPORTS:
        dv.add_report(report_class())
    for test_data in TEST_DATAS:
        dv.add_test_data(test_data.name, get_resource(test_data.source_path))
    dv.run()


if __name__ == "__main__":
    main()
