from datetime import datetime
from dataview.base import Report
import asq


class StudentAgeReport(Report):

    currentYear = datetime.today().year
    valid_assessments = ["ACT", "SAT", "TSI"]

    def calculate_age(self, student):
        """
        Example of how to calculate age of student

        :param student:
        :return:
        """
        student_id = student.get("student_unique_id")
        student_dob = student.get("birth_date")
        student_first_name = student.get("first_name")
        student_last_name = student.get("last_name")
        student_assessment = student.get("assessment")

        student_age = self.currentYear - int(student_dob[:4])

        return {
            "student_id": student_id,
            "first_name": student_first_name,
            "last_name": student_last_name,
            "age": student_age,
            "assessment": student_assessment,
        }

    def assessment_count(self, grouping):

        assessments_taken = [g["assessment"] for g in grouping]
        result = {**grouping[0], "assessments": list(set(assessments_taken))}
        result.pop("assessment")

        return result

    def assessment_filter(self, assessment):
        return (
            assessment.get("assessment_reference", {}).get("title", "")
            in self.valid_assessments
        )

    def run(self, pipes):
        """
        Uses student iterator from pipes and returns an iterator of student and ages

        :param pipes:
        :return:
        """
        student_iterator = pipes["Student"]
        assessment_iterator = pipes["StudentAssessment"]

        assessment_iterator.set_filter(self.assessment_filter)

        q = asq.query(student_iterator)

        q_student_assessments = q.join(
            assessment_iterator,
            lambda student: student["student_unique_id"],
            lambda assessment: assessment["student_reference"]["studentUniqueId"],
            lambda student, assessment: {
                **student,
                "assessment": assessment["assessment_reference"]["title"],
            },
        )

        q_results = (
            q_student_assessments.select(self.calculate_age)
            .group_by(lambda record: record["student_id"])
            .select(self.assessment_count)
        )

        return q_results

    def get_name(self):
        return "Student Age"

    def get_code(self):
        return "STUDENT_AGE"

    def get_key_properties(self):
        return ["student_unique_id"]

    def get_report_schema(self):
        return {"type": "object", "properties": {"student_info": {"type": "object"}}}

    def get_report_permissions(self):
        return [{"role_id": 20, "domain_type": "LEA"}]

    def get_required_entities(self):
        return ["Student", "StudentAssessment"]
