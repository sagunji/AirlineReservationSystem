import os

RESOURCE_PATH = os.path.join(os.path.dirname(__file__), "resources")


def get_resource(name):
    """
    Method to get resource from the given name
    :param name: name of resource
    :return: resource path
    """
    return os.path.join(RESOURCE_PATH, name)
